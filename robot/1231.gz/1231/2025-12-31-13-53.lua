VISION_IP   = "192.168.6.83"
VISION_PORT = 5020
SOCKET_NAME = "socket_0"

tcp = 0

-- 固定笛卡尔姿态
FIX_Z  = 88
FIX_RX = 179
FIX_RY = 0.5

-- MoveL 参数
TOOL_NUM      = 0    
WORKPIECE_NUM = 0    

SPEED = 90       
ACC   = 80        
OVL   = 90        

BLEND_R = -1      
SEARCH_FLAG = 0   
OFFSET_FLAG = 0   

-- 偏移量
OFFSET_X, OFFSET_Y, OFFSET_Z = 0.0, 0.0, 0.0
OFFSET_RX, OFFSET_RY, OFFSET_RZ = 0.0, 0.0, 0.0

EX1, EX2, EX3, EX4 = 0.0, 0.0, 0.0, 0.0  

OACC = 100              
VEL_ACC_PARAM_MODE = 0  

-- 状态变量
local next_pose = nil  -- 存储下一次的视觉位姿
local put_index = 1    -- 当前放置点索引 (1-5)
local is_first_grasp = true  -- 是否为第一次抓取

print("机器人客户端启动...")

-- 连接视觉函数
function connect_vision()
    if tcp == 0 then
        print("尝试连接视觉服务端...")
        tcp = SocketOpen(VISION_IP, VISION_PORT, SOCKET_NAME)
        if tcp == 1 then
            print("连接成功")
        else
            WaitMs(1000)
        end
    end
    return tcp == 1
end

-- 请求视觉位姿函数
function request_vision_pose()
    if tcp == 1 then
        WaitMs(200)  -- 给服务端缓冲时间
        local send_ret = SocketSendString("Need Pose", SOCKET_NAME, 0)
        if send_ret ~= 0 then
            print("发送失败，尝试重连")
            SocketClose(SOCKET_NAME)
            tcp = 0
            return nil
        else
            recv_str = SocketReadString(SOCKET_NAME, 0)
            
            if recv_str == nil or recv_str == "" or recv_str == "timeout" then
                if recv_str == "timeout" then
                    print("接收超时")
                    SocketClose(SOCKET_NAME)
                    tcp = 0
                end
                return nil
            elseif recv_str == "NO_POSE" then
                print("视觉暂无位姿")
                return nil
            else
                -- 解析位姿数据
                local x, y, rz = string.match(recv_str, "([%-%d%.]+)%s+([%-%d%.]+)%s+([%-%d%.]+)")
                if x and y and rz then
                    return {
                        x = tonumber(x),
                        y = tonumber(y),
                        rz = tonumber(rz)
                    }
                else
                    print("数据格式不匹配: " .. tostring(recv_str))
                    return nil
                end
            end
        end
    end
    return nil
end

-- 根据索引获取放置点名称
function get_put_point(index)
    if index == 1 then
        return put1
    elseif index == 2 then
        return put2
    elseif index == 3 then
        return put3
    elseif index == 4 then
        return put4
    elseif index == 5 then
        return put5
    else
        return put1  -- 默认返回put1
    end
end

-- 执行抓取动作函数
function execute_grasp(pose_data)
    local x, y, rz = pose_data.x, pose_data.y, pose_data.rz
    
    print(string.format("开始抓取: X=%.2f, Y=%.2f, RZ=%.2f", x, y, rz))
    
    -- 逆解与运动到抓取点
    local j1,j2,j3,j4,j5,j6 = GetInverseKin(WORKPIECE_NUM, x, y, FIX_Z, FIX_RX, FIX_RY, rz, -1)
    
    MoveL(
        j1,j2,j3,j4,j5,j6, x, y, FIX_Z, FIX_RX, FIX_RY, rz,
        TOOL_NUM, WORKPIECE_NUM, SPEED, ACC, OVL,
        EX1, EX2, EX3, EX4, BLEND_R, SEARCH_FLAG, OFFSET_FLAG,
        OFFSET_X, OFFSET_Y, OFFSET_Z, OFFSET_RX, OFFSET_RY, OFFSET_RZ,
        OACC, VEL_ACC_PARAM_MODE
    )
    
    -- 抓取物体（假设DO1控制夹爪）
    SetDO(1, 1, 0, 1)  -- 夹爪闭合
    WaitMs(1500)
    
    -- 移出抓取区域
    PTP(y抓取移出点1, 20, -1, 0)
    PTP(y抓取过渡点5, 20, -1, 0)
end

-- 执行放置动作函数
function execute_place()
    -- 获取当前放置点
    local current_put_point = get_put_point(put_index)
    
    print(string.format("放置到: put%d", put_index))
    
    -- 移动到放置点
    PTP(current_put_point, 20, -1, 0)
    
    -- 放置物体（假设DO1控制夹爪）
    SetDO(1, 0, 0, 1)  -- 夹爪打开
    WaitMs(1500)
    
    -- 更新放置点索引（循环1-5）
    put_index = put_index % 5 + 1
    
    -- 移出放置区域
    PTP(y放置移出点1, 20, -1, 0)
end

-- 主程序初始化
print("初始化运动...")
PTP(y放置移出点1, 20, -1, 0)
PTP(y抓取过渡点1, 20, -1, 0)
PTP(y抓取过渡点3, 20, -1, 0)
PTP(点4, 20, -1, 0)

-- 主循环
while true do
    -- 确保连接
    if not connect_vision() then
        WaitMs(1000)
        goto continue
    end
    
    -- 第一次抓取或需要新位姿时请求
    if is_first_grasp or next_pose == nil then
        print("请求视觉位姿...")
        next_pose = request_vision_pose()
        
        if next_pose == nil then
            print("未获得有效位姿，等待...")
            WaitMs(2000)
            goto continue
        end
        
        is_first_grasp = false
    end
    
    -- 执行抓取
    execute_grasp(next_pose)
    
    -- 移动到点4并立即请求下一个位姿
    PTP(点4, 20, -1, 0)
    
    -- 在放置前提前请求下一个位姿
    print("在放置过程中提前请求下一个位姿...")
    next_pose = request_vision_pose()
    if next_pose == nil then
        print("未能获取下一个位姿，将在下次循环重试")
    end
    
    -- 执行放置
    execute_place()
    
    -- 返回抓取等待点
    PTP(点4, 20, -1, 0)
    PTP(y抓取过渡点1, 20, -1, 0)
    
    -- 如果已经有了下一个位姿，直接进入下一次抓取
    if next_pose ~= nil then
        print("已有下一个位姿，继续抓取...")
        -- 直接进入下一次循环
    else
        print("等待下一个位姿...")
        WaitMs(1000)
    end
    
    ::continue::
    WaitMs(50)
end